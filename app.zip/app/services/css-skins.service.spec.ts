import { TestBed } from '@angular/core/testing';

import { CssSkinsService } from './css-skins.service';

describe('CssSkinsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CssSkinsService = TestBed.get(CssSkinsService);
    expect(service).toBeTruthy();
  });
});
